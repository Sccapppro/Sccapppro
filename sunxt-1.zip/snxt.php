<?php
error_reporting(0);
header("Content-Type: application/vnd.apple.mpegurl");
$ckie = file_get_contents("sun.txt");
$csrf = file_get_contents("csrf.txt");
$getid = $_GET['id'];
$json = json_decode(file_get_contents("sunnxt.json"), true);
foreach($json['SunNxt'] as $v) {
	if($v['id'] === $getid) {
		$name = $v['name'];
		$q = $v['quality'];

	}
}
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://www.sunnxt.com/movie/getMediaLinkForCounter",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS =>"{\"params\":{\"id\":\"38926\",\"counter\":3}}",
  CURLOPT_HTTPHEADER => array(
    "x-csrf-token: ".$csrf,
    "user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.61 Safari/537.36",
    "x-requested-with: XMLHttpRequest",
    "content-type: application/json;charset=UTF-8",
    "cookie: ".$ckie,
  ),
));

$response = curl_exec($curl);
curl_close($curl);
$json = json_decode($response, true);
$base = $json['values'][0]['link'];
//echo $base."<br>";
$burl = "https://suntvlive.s.llnwi.net/SunNews/SunNews.isml/";
$b_url = "stream.php?ts=https://suntvlive.s.llnwi.net/SunNews/SunNews.isml/";
//$ua = $_SERVER['HTTP_USER_AGENT'];
if ($ua != "") {
	$useragent = $ua;
} else {
	$useragent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.61 Safari/537.36";
}

$context = stream_context_create(array('http' => array(
    'method'        => "GET",
    'header'        => "User-Agent: ".$useragent,
    'ignore_errors' => true
)));

$string = file_get_contents($base, false, $context);
$stream = str_replace('SunNews', $burl."SunNews", $string);

preg_match("/(?<=SDR\n).*/", $stream, $sunnews);
$e = $sunnews[0];
$f = file_get_contents($e, false, $context);
$g = preg_replace("/SunNews/", $b_url."$0", $f);
$ori = array("SunNews", "1499968");
$rep = array($name, $q);
$h= str_replace($ori, $rep, $g);
if($getid == "14020") {
    $add = 14398;
    $j = preg_replace_callback(
    '/(?<=5000000-).+?(?=.ts)/',
    function($match) use ($add) { return (($match[0] + $add)); }, $h);
    echo $j; 
} elseif($getid == "14019") {
    $sub = 20;
    $j = preg_replace_callback(
    '/(?<=5000000-).+?(?=.ts)/',
    function($match) use ($sub) { return (($match[0] - $sub)); }, $h);
    echo $j;
} elseif($getid == "26569" || $getid == "26567" || $getid == "9017" || $getid == "9015" || $getid == "9027" || $getid == "26571" || $getid == "9018" || $getid == "9019" || $getid == "26575" || $getid == "30835" || $getid == "26577" || $getid == "9029" || $getid == "26576" || $getid == "9014" || $getid == "9022" || $getid == "26573" || $getid == "75117") {
    $sub = 2;
    $j = preg_replace_callback(
    '/(?<=1499968-).+?(?=.ts)/',
    function($match) use ($sub) { return (($match[0] - $sub)); }, $h);
    echo $j;
} elseif($getid == "9026" || $getid == "26572") {
    $sub = 20;
    $j = preg_replace_callback(
    '/(?<=1499968-).+?(?=.ts)/',
    function($match) use ($sub) { return (($match[0] - $sub)); }, $h);
    echo $j;
} elseif($getid == "9023") {
    $sub = 6;
    $j = preg_replace_callback(
    '/(?<=1499968-).+?(?=.ts)/',
    function($match) use ($sub) { return (($match[0] - $sub)); }, $h);
    echo $j;
} else {
    echo $h;
}

?>